from tkinter import *
from tkinter.ttk import Progressbar
from tkinter.messagebox import showinfo, showwarning, askyesno
import random
from PIL import ImageTk, Image          ## Импортируем библиотеку для открытия фоток
import os
import copy
import math

okno = Tk()
okno.title("Обучение")
# okno.geometry("350x350+550+250")
okno.geometry("230x140+550+250")
# okno.resizable(False, False)

def Kolob(n,w):
                                        ## Ищем нужные нам строки из файла
    f = open('vop(%d).txt' %w,encoding = 'UTF-8')
    a = ''
    k=0
    for line in f:
        if k == n : a = line
        k+=1
    a = a[:len(a)-1]
    return(a)

       ## Показываем ответ
def Otvet(n,w):
    n = n+1
    f = Image.open('otv_jpg%d\otvet%d.jpg'%(w,n))
    f.show()
                            ## Находим максимальное число вопросов:
def Maxotv(w):
    k = 0
    if w == 1:
        f = open('vop(1).txt',encoding = 'UTF-8')
    elif w == 2:
        f = open('vop(2).txt',encoding='UTF-8')
    elif w ==3:
        f = open('vop(3).txt',encoding = 'UTF-8')
    for line in f:
        k +=1
    return(k)


def exam1(w):
    s = Maxotv(w)
    h = []     ## Создаем 2 списка для помещения туда вопросов и "ответов"
    f = []
    t2 =  copy.deepcopy(t1)
    t2["vsego"] = 0
    t2["neprav"] = 0
    while len(f)<6 :
        d = random.randint(0,s-1)
        if not(d in f):
            f.append(d)
    for i in range(0,6):    ##
        h.append(2)
    def zadaem_exam(h):
        children = Toplevel(okno)
        children.title("Экзамен")

        label_ch_1 = Label(children, text = "", bg = "orange")
        label_ch_12 = Label(children, text = "Вы ответили на вопрос?")
        button_ch_1 = Button(children, text = "Да")
        button_ch_2 = Button(children, text = "Да" )
        button_ch_3 = Button(children, text = "Нет" )
        label_ch_3= Label(children, text = "Вы правильно ответили на вопрос?")
        while (2 in h):     ## Проверяем есть ли неотвеченные вопросы

            u = random.randint(0,5)
            if h[u]!=0 :                        ## Если вопрос остался в списке, то задаем его



                def Otvet_pokaz_exam(w,q):
                    def pravilno_exam(h):
                        h[u] = h[u]-2
                        t2["vsego"] = int(t2["vsego"])+ 1

                        children.destroy()
                        zadaem_exam(h)

                    def nepravilno_exam(h):
                        h[u] = h[u]-2
                        t2["vsego"] = int(t2["vsego"])+ 1
                        t2["neprav"] = int(t2["neprav"])+ 1
                        children.destroy()
                        zadaem_exam(h)



                    Otvet(q,w)         ## Показываем ответ
                    label_ch_3.grid()
                    button_ch_2["command"] = lambda: pravilno_exam(h)
                    button_ch_3["command"] = lambda: nepravilno_exam(h)
                    button_ch_2.grid()
                    button_ch_3.grid()



                label_ch_1["text"] = Kolob(f[u],w)
                button_ch_1["command"] = lambda : Otvet_pokaz_exam(w,f[u])
                label_ch_1.grid()
                label_ch_12.grid()
                button_ch_1.grid()
                mainloop()
            else:
                children.destroy()
                zadaem_exam(h)
        else:
            Label(children, text = "Статистика:").grid()
            Label(children, text = "Процент правильных ответов в экзамене, который вы прошли:").grid()
            progress = Progressbar(children, orient = HORIZONTAL, length = 300, mode = 'determinate')
            progress['value'] = round(((t2["vsego"]-t2["neprav"])/t2["vsego"])*100)
            label_progres = Label(children, text = str(round(((t2["vsego"]-t2["neprav"])/t2["vsego"])*100))+"%").grid()
            children.update_idletasks()
            progress.grid()
            t1["vsego"] =int(t1["vsego"])
            t1["neprav"] =int(t1["neprav"])
            t2["vsego"] += t1["vsego"]
            t2["neprav"] += t1["neprav"]
            Label(children, text = "Процент правильных ответов в экзамене, который вы прошли за все время:").grid()
            progress = Progressbar(children, orient = HORIZONTAL, length = 300, mode = 'determinate')
            progress['value'] = round(((t2["vsego"]-t2["neprav"])/t2["vsego"])*100)
            label_progres = Label(children, text = str(round(((t2["vsego"]-t2["neprav"])/t2["vsego"])*100))+"%").grid()
            children.update_idletasks()
            progress.grid()
            def ismena(k):
                if k ==2:
                    t1["vsego"] =t2["vsego"]
                    t1["neprav"] =t2["neprav"]
                    t2["vsego"] = 0
                    t2["neprav"] = 0

                with open ('login_statistika.txt','r',encoding = 'ANSI') as file2:
                    old_login = file2.read()

                    new_login = old_login.replace(str(t1), str(t2))
                with open ('login_statistika.txt', 'w',encoding = 'ANSI') as file2:
                    file2.write(new_login)
                if k ==2:
                    showinfo("Внимание:","Выполнено!")
            ismena(1)
            Button(children, text = "Очистить статистику!", command = lambda: ismena(2)).grid()



            return
    zadaem_exam(h)
    return



def test1(w,vihod):
    okno.geometry("350x350+550+250")
    s = Maxotv(w)//10+1
    label2["text"] = "Максисальный уровень: " + str(s)
    label3["text"] = "Введите уровень, который вы хотите пройти:"
    label2.grid()
    label3.grid()
    entX.grid()
    prodolgit_button["command"] = lambda: prodolgit(s,w)
    prodolgit_button.grid()
    return




def prodolgit(s,w):
    vihod = 1
    def proverka(n,s,w):
            if n<=s: ## Проверяем: Введенный уровень меньше максимального или нет
                def vopr(n,w):
                    # okno.withdraw()
                    # k =1
                    global h
                    g = []                 ## Создаем 2 списка для помещения туда вопросов и "ответов"
                    h = []
                    i = (n-1)*10
                    p = y = 0
                    while i+y<i+10 :
                        if Kolob(i+y,w) != "":
                            g.append(Kolob(i+y,w))
                            p+=1
                                                        #(может это последний уровень и там всего 3 вопроса)
                        y +=1
                    for i in range(0,p):    ##
                        h.append(2)
                    def zadaem(h,w,n):
                        children = Toplevel(okno)
                        label_ch_1 = Label(children, text = "", bg = "orange")
                        label_ch_12 = Label(children, text = "Вы ответили на вопрос?")
                        button_ch_1 = Button(children, text = "Да")
                        button_ch_2 = Button(children, text = "Да" )
                        button_ch_3 = Button(children, text = "Нет" )
                        label_ch_3= Label(children, text = "Вы правильно ответили на вопрос?")
                        while (4 in h) or (2 in h):     ## Проверяем есть ли неотвеченные вопросы

                            u = random.randint(0,(p-1))
                            if h[u]!=0 :                        ## Если вопрос остался в списке, то задаем его


                                def Otvet_pokaz(n,w):
                                    def pravilno(h):
                                        h[u] = h[u]-2
                                        children.destroy()
                                        zadaem(h,w,n)


                                    def nepravilno(h):
                                        children.destroy()
                                        zadaem(h,w,n)




                                    Otvet((n-1)*10+u,w)         ## Показываем ответ
                                    label_ch_3.grid()
                                    # entS2 = Entry(children)
                                    # entS2.grid()
                                    button_ch_2["command"] = lambda: pravilno(h)
                                    button_ch_3["command"] = lambda: nepravilno(h)
                                    button_ch_2.grid()
                                    button_ch_3.grid()




                                label_ch_1["text"] = g[u]
                                button_ch_1["command"] = lambda : Otvet_pokaz(n,w)
                                label_ch_1.grid()
                                label_ch_12.grid()
                                button_ch_1.grid()
                                # children.deiconify() Обучение
                                mainloop()
                            else:
                                children.destroy()
                                zadaem(h,w,n)
                        else:
                            children.destroy()
                            children3 = Toplevel(okno)
                            children3.title("Информация!")
                            Label(children3, text = "                 Вы прошли уровень № %d \n Можете ввести в основном экране другой или перейти к Экзамену!\n                    Удачи!" %n).grid()

                            global vihod
                            vihod = 2
                            return


                    if vihod == 2:
                        return
                    else:
                         zadaem(h,w,n)
                vopr(n,w)
                return n    ## вызывааем функцию с уровнем, который мы ввели и возращаем "к" для выхода из программы


            else:
                if vihod == 1:
                    showwarning("Внимание!", "Этот уровень не существует!")
            return vihod

    try:
        n = int(entX.get())
    except ValueError:
        showwarning("Внимание!","Введите целое число!")
    if vihod == 1:
        proverka(n,s,w)
    else:
        return


def vibor(w):
    okno.geometry("342x340+550+250")
    def spravka():
        showinfo("Правила:","""Тест: дается 10 вопросов, отвечаете на них, пока не ответите по 2 раза на каждый вопрос правильно \nЭкзамен: дается 6 вопросов, после прохождения выдается статистика""")
    label12["bg"] = "yellow"
    if w ==1:
        label12["text"] = "Будем готовиться к предмету: Математический анализ)"
    else:
        label12["text"] = "Будем готовиться к предмету: Основы алгоритмизации!"
    label12.grid(pady=5, padx=15)
    label11.grid(pady=5, padx=15)
    button11.grid(pady=5, padx=15)
    button12.grid(pady=5, padx=15)
    button13.grid(pady=5, padx=15)
    # photo = ImageTk.PhotoImage(Image.open("kartinka2.jpg"))
    # resized = photo.resize((20, 20))
    # resized.save('out.png')
    # lb_photo = Label(okno, image = photo)
    # lb_photo.image = photo
    # lb_photo.grid(column = 2)
    vihod = 1
    button11["command"] = lambda: exam1(w)
    button12["command"] = lambda: test1(w, vihod)
    button13["command"] = spravka


def login_pro(entX1):
    name_p = entX1.get()
    global t1
    t1 = {}
    with open('login_statistika.txt','r',encoding = 'ANSI' ) as file:
        for line in file:
            t = {}
            line = line[1:len(line)-2]
            a = line.split(",")
            for i in a:
                i = i.replace("\'", "")
                i = i.replace(" ","")
                i = i.split(":")

                t.update(dict({i[0]:i[1]}))

            if t["name"] == name_p:
                t1 = t


                ask1 = askyesno("Внимание!","Вы хотите зайти под существующим логином?")
                if ask1 == False:
                    showinfo("Объявление:","Введите другой логин!")
                    try:
                        children1.destroy()
                    except UnboundLocalError:
                        children2.destroy()
                    children2 = Toplevel(okno)
                    children2.title("Вход")
                    label10 = Label(children2, text = "Введите ван логин:")
                    entX1 = Entry(children2)
                    # entX1.insert(0, "Oleg")
                    entX1.focus()
                    label10.grid()
                    entX1.grid()
                    button10 =  Button(children2, text = "Продолжить", command =  lambda: login_pro(entX1)).grid()

                    return
                else:
                    showinfo("","Здравствуйте, %s!" %(name_p))
    if t1 == {}:
        with open("login_statistika.txt", "a",encoding = 'ANSI') as file:
            fails = {}
            fails["name"] = name_p
            fails["vsego"] = 0
            fails["neprav"] = 0
            t1 = fails
            fails = str(fails)+"\n"
            file.write(fails)
            showinfo("","Здравствуйте, %s!" %(name_p))

    okno.deiconify()
    try:
        children1.destroy()
    except UnboundLocalError:
        children2.destroy()


if os.path.exists("login_statistika.txt"):
    pass
else:
    file = open("login_statistika.txt", 'w' ,encoding = 'ANSI')
    file.close()


children1 = Toplevel(okno)
children1.geometry("155x100+550+250")
children1.resizable(False, False)
children1.title("Вход")
label10 = Label(children1, text = "Введите ваш логин:")
entX1 = Entry(children1)
# entX1.insert(0, "Oleg")
entX1.focus()
label10.grid(pady=5, padx=15)
entX1.grid(pady=5, padx=15)
button10 =  Button(children1, text = "Продолжить", command = lambda: login_pro(entX1)).grid(pady=5, padx=15)


label1 = Label(okno, text = "Выберите к чему будете готовиться:").grid(pady=5, padx=15)
button1 =  Button(okno, text = "Математический анализ", command = lambda: vibor(1)).grid(pady=5, padx=15)
button2 = Button(okno, text = "Основы алгоритмизации", command = lambda: vibor(3)).grid(pady=5, padx=15)
label12 = Label(okno, text = "")
label11 = Label(okno, text = "Выбирите, какой из тестов вы будете проходить:", pady = 10)
# label11.grid()
button11= Button(okno, text = "Экзамен")
button12= Button(okno, text = "Тест")
button13 = Button(okno, text = "Справка")
label2 = Label()
label3 = Label()
global entX
entX = Entry()
entX.insert(0, "1")
prodolgit_button = Button(okno, text = "Продолжить")
okno.withdraw()


  ## Здесь мы определяем сколько ответов в каком-то из файлов(текстовые)

mainloop()